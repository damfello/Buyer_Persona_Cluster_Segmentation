```python
## Libraries 

import numpy as np
import pandas as pd
import datetime
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import colors
import seaborn as sns
import matplotlib.pyplot as plt, numpy as np
from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from yellowbrick.cluster import KElbowVisualizer
from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
from matplotlib.colors import ListedColormap
from sklearn import metrics
import warnings
import sys
if not sys.warnoptions:
    warnings.simplefilter("ignore")
np.random.seed(42) 



```


```python
##Upload Data

data = pd.read_csv(r"C:\Users\Damfello\Desktop\Sexy Daticos\buyerpersona_supermarket.csv") ## , sep="\t")
print("Number of datapoints:", len(data))

# Show a Resume
data.head()
```

    Number of datapoints: 2240
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idClient</th>
      <th>enrolmentDate</th>
      <th>educationLevel</th>
      <th>yearBirth</th>
      <th>daysLastBuy</th>
      <th>maritalstatus</th>
      <th>kids</th>
      <th>teenagers</th>
      <th>income</th>
      <th>wines</th>
      <th>...</th>
      <th>webVisits_Month</th>
      <th>camp1_Received</th>
      <th>camp2_Received</th>
      <th>camp3_Received</th>
      <th>camp4_Received</th>
      <th>camp5_Received</th>
      <th>complain</th>
      <th>Z_CostContact</th>
      <th>Z_Revenue</th>
      <th>response</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5524</td>
      <td>04-09-2012</td>
      <td>Graduation</td>
      <td>1957</td>
      <td>58</td>
      <td>Single</td>
      <td>0</td>
      <td>0</td>
      <td>58138.0</td>
      <td>635</td>
      <td>...</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2174</td>
      <td>08-03-2014</td>
      <td>Graduation</td>
      <td>1954</td>
      <td>38</td>
      <td>Single</td>
      <td>1</td>
      <td>1</td>
      <td>46344.0</td>
      <td>11</td>
      <td>...</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4141</td>
      <td>21-08-2013</td>
      <td>Graduation</td>
      <td>1965</td>
      <td>26</td>
      <td>Together</td>
      <td>0</td>
      <td>0</td>
      <td>71613.0</td>
      <td>426</td>
      <td>...</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6182</td>
      <td>10-02-2014</td>
      <td>Graduation</td>
      <td>1984</td>
      <td>26</td>
      <td>Together</td>
      <td>1</td>
      <td>0</td>
      <td>26646.0</td>
      <td>11</td>
      <td>...</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5324</td>
      <td>19-01-2014</td>
      <td>PhD</td>
      <td>1981</td>
      <td>94</td>
      <td>Married</td>
      <td>1</td>
      <td>0</td>
      <td>58293.0</td>
      <td>173</td>
      <td>...</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 29 columns</p>
</div>




```python
# Exploring

data.info()
data.shape

## Conlusion:
## Missing values in variables Income
## enrolmentDate its not a date format

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2240 entries, 0 to 2239
    Data columns (total 29 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   idClient          2240 non-null   int64  
     1   enrolmentDate     2240 non-null   object 
     2   educationLevel    2240 non-null   object 
     3   yearBirth         2240 non-null   int64  
     4   daysLastBuy       2240 non-null   int64  
     5   maritalstatus     2240 non-null   object 
     6   kids              2240 non-null   int64  
     7   teenagers         2240 non-null   int64  
     8   income            2216 non-null   float64
     9   wines             2240 non-null   int64  
     10  fruits            2240 non-null   int64  
     11  meat              2240 non-null   int64  
     12  fish              2240 non-null   int64  
     13  candy             2240 non-null   int64  
     14  gold              2240 non-null   int64  
     15  dealsPurchases    2240 non-null   int64  
     16  webPurchases      2240 non-null   int64  
     17  catalogPurchases  2240 non-null   int64  
     18  storePurchases    2240 non-null   int64  
     19  webVisits_Month   2240 non-null   int64  
     20  camp1_Received    2240 non-null   int64  
     21  camp2_Received    2240 non-null   int64  
     22  camp3_Received    2240 non-null   int64  
     23  camp4_Received    2240 non-null   int64  
     24  camp5_Received    2240 non-null   int64  
     25  complain          2240 non-null   int64  
     26  Z_CostContact     2240 non-null   int64  
     27  Z_Revenue         2240 non-null   int64  
     28  response          2240 non-null   int64  
    dtypes: float64(1), int64(25), object(3)
    memory usage: 507.6+ KB
    




    (2240, 29)




```python
## Exploring 

data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idClient</th>
      <th>yearBirth</th>
      <th>daysLastBuy</th>
      <th>kids</th>
      <th>teenagers</th>
      <th>income</th>
      <th>wines</th>
      <th>fruits</th>
      <th>meat</th>
      <th>fish</th>
      <th>...</th>
      <th>webVisits_Month</th>
      <th>camp1_Received</th>
      <th>camp2_Received</th>
      <th>camp3_Received</th>
      <th>camp4_Received</th>
      <th>camp5_Received</th>
      <th>complain</th>
      <th>Z_CostContact</th>
      <th>Z_Revenue</th>
      <th>response</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2216.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>...</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.000000</td>
      <td>2240.0</td>
      <td>2240.0</td>
      <td>2240.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5592.159821</td>
      <td>1968.805804</td>
      <td>49.109375</td>
      <td>0.444196</td>
      <td>0.506250</td>
      <td>52247.251354</td>
      <td>303.935714</td>
      <td>26.302232</td>
      <td>166.950000</td>
      <td>37.525446</td>
      <td>...</td>
      <td>5.316518</td>
      <td>0.064286</td>
      <td>0.013393</td>
      <td>0.072768</td>
      <td>0.074554</td>
      <td>0.072768</td>
      <td>0.009375</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.149107</td>
    </tr>
    <tr>
      <th>std</th>
      <td>3246.662198</td>
      <td>11.984069</td>
      <td>28.962453</td>
      <td>0.538398</td>
      <td>0.544538</td>
      <td>25173.076661</td>
      <td>336.597393</td>
      <td>39.773434</td>
      <td>225.715373</td>
      <td>54.628979</td>
      <td>...</td>
      <td>2.426645</td>
      <td>0.245316</td>
      <td>0.114976</td>
      <td>0.259813</td>
      <td>0.262728</td>
      <td>0.259813</td>
      <td>0.096391</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.356274</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>1893.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1730.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2828.250000</td>
      <td>1959.000000</td>
      <td>24.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>35303.000000</td>
      <td>23.750000</td>
      <td>1.000000</td>
      <td>16.000000</td>
      <td>3.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>5458.500000</td>
      <td>1970.000000</td>
      <td>49.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>51381.500000</td>
      <td>173.500000</td>
      <td>8.000000</td>
      <td>67.000000</td>
      <td>12.000000</td>
      <td>...</td>
      <td>6.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>8427.750000</td>
      <td>1977.000000</td>
      <td>74.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>68522.000000</td>
      <td>504.250000</td>
      <td>33.000000</td>
      <td>232.000000</td>
      <td>50.000000</td>
      <td>...</td>
      <td>7.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>11191.000000</td>
      <td>1996.000000</td>
      <td>99.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>666666.000000</td>
      <td>1493.000000</td>
      <td>199.000000</td>
      <td>1725.000000</td>
      <td>259.000000</td>
      <td>...</td>
      <td>20.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 26 columns</p>
</div>




```python
### Cleaning

data = data.dropna()
print("The total number of data-points after removing the rows with missing values are:", len(data))
```

    The total number of data-points after removing the rows with missing values are: 2216
    


```python
## Formatting enrolmentDate 

data["enrolmentDate"] = pd.to_datetime(data["enrolmentDate"])
dates = [] 
for i in data["enrolmentDate"]:
    i = i.date()
    dates.append(i)
    
# Dates of the newest and oldest enrolment dates from clients


print ("Newest date of a client enrolment:", max(dates))
print("Oldest date of a client enrolment:", min(dates)) 


```

    Newest date of a client enrolment: 2014-12-06
    Oldest date of a client enrolment: 2012-01-08
    


```python
## Crate "Customer_For"
### Number of days it took for them to start buying from the most recent date of enrollment (Max enrollment-Date)

    
    
days = []
d1 = max(dates) #Consideramos con el cliente más reciente registrado
for i in dates:
    delta = d1 - i
    days.append(delta)
data["Customer_For"] = days
data["Customer_For"] = pd.to_numeric(data["Customer_For"], errors="coerce")


data.describe()






```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idClient</th>
      <th>yearBirth</th>
      <th>daysLastBuy</th>
      <th>kids</th>
      <th>teenagers</th>
      <th>income</th>
      <th>wines</th>
      <th>fruits</th>
      <th>meat</th>
      <th>fish</th>
      <th>...</th>
      <th>camp1_Received</th>
      <th>camp2_Received</th>
      <th>camp3_Received</th>
      <th>camp4_Received</th>
      <th>camp5_Received</th>
      <th>complain</th>
      <th>Z_CostContact</th>
      <th>Z_Revenue</th>
      <th>response</th>
      <th>Customer_For</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>...</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.0</td>
      <td>2216.0</td>
      <td>2216.000000</td>
      <td>2.216000e+03</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5588.353339</td>
      <td>1968.820397</td>
      <td>49.012635</td>
      <td>0.441787</td>
      <td>0.505415</td>
      <td>52247.251354</td>
      <td>305.091606</td>
      <td>26.356047</td>
      <td>166.995939</td>
      <td>37.637635</td>
      <td>...</td>
      <td>0.064079</td>
      <td>0.013538</td>
      <td>0.073556</td>
      <td>0.074007</td>
      <td>0.073105</td>
      <td>0.009477</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.150271</td>
      <td>4.423735e+16</td>
    </tr>
    <tr>
      <th>std</th>
      <td>3249.376275</td>
      <td>11.985554</td>
      <td>28.948352</td>
      <td>0.536896</td>
      <td>0.544181</td>
      <td>25173.076661</td>
      <td>337.327920</td>
      <td>39.793917</td>
      <td>224.283273</td>
      <td>54.752082</td>
      <td>...</td>
      <td>0.244950</td>
      <td>0.115588</td>
      <td>0.261106</td>
      <td>0.261842</td>
      <td>0.260367</td>
      <td>0.096907</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.357417</td>
      <td>2.008532e+16</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>1893.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1730.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2814.750000</td>
      <td>1959.000000</td>
      <td>24.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>35303.000000</td>
      <td>24.000000</td>
      <td>2.000000</td>
      <td>16.000000</td>
      <td>3.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.000000</td>
      <td>2.937600e+16</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>5458.500000</td>
      <td>1970.000000</td>
      <td>49.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>51381.500000</td>
      <td>174.500000</td>
      <td>8.000000</td>
      <td>68.000000</td>
      <td>12.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.000000</td>
      <td>4.432320e+16</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>8421.750000</td>
      <td>1977.000000</td>
      <td>74.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>68522.000000</td>
      <td>505.000000</td>
      <td>33.000000</td>
      <td>232.250000</td>
      <td>50.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>0.000000</td>
      <td>5.927040e+16</td>
    </tr>
    <tr>
      <th>max</th>
      <td>11191.000000</td>
      <td>1996.000000</td>
      <td>99.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>666666.000000</td>
      <td>1493.000000</td>
      <td>199.000000</td>
      <td>1725.000000</td>
      <td>259.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>3.0</td>
      <td>11.0</td>
      <td>1.000000</td>
      <td>9.184320e+16</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 27 columns</p>
</div>




```python
## Unique values in categories MaritalStatus & educationLevel



print("Total categories in the feature Marital_Status:\n", data["maritalstatus"].value_counts(), "\n")
print("Total categories in the feature Education:\n", data["educationLevel"].value_counts())


```

    Total categories in the feature Marital_Status:
     Married     857
    Together    573
    Single      471
    Divorced    232
    Widow        76
    Alone         3
    YOLO          2
    Absurd        2
    Name: maritalstatus, dtype: int64 
    
    Total categories in the feature Education:
     Graduation    1116
    PhD            481
    Master         365
    2n Cycle       200
    Basic           54
    Name: educationLevel, dtype: int64
    


```python
#Create new Metrics Variables


#Age of Customers
data["Age"] = 2023-data["yearBirth"]

#Total Expenditures

data["Expenditure"] = data["wines"]+ data["fruits"]+ data["meat"]+ data["fish"]+ data["candy"]+ data["gold"]

#Derive the Group Living according to civil status/Marital_status
data["Group_Living"]=data["maritalstatus"].replace({"Married":"Partner", "Together":"Partner", "Absurd":"Alone", "Widow":"Alone", "YOLO":"Alone", "Divorced":"Alone", "Single":"Alone",})

#Total Sons
data["Sons"]=data["kids"]+data["teenagers"]

# Total Family Members
data["FamilySize"] = data["Group_Living"].replace({"Alone": 1, "Partner":2})+ data["Sons"]


# Parents
data["SonPadres"] = np.where(data.Sons> 0, 1, 0)

# Grouping Education Levels
data["Education"]=data["educationLevel"].replace({"Basic":"Undergraduate","2n Cycle":"Undergraduate", "Graduation":"Graduate", "Master":"Postgraduate", "PhD":"Postgraduate"})


#Dropping some of the redundant features
to_drop = ["maritalstatus", "enrolmentDate", "Z_CostContact", "Z_Revenue", "yearBirth", "idClient", "educationLevel"]
data = data.drop(to_drop, axis=1)

```


```python
## Exploring new metrics

data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>daysLastBuy</th>
      <th>kids</th>
      <th>teenagers</th>
      <th>income</th>
      <th>wines</th>
      <th>fruits</th>
      <th>meat</th>
      <th>fish</th>
      <th>candy</th>
      <th>gold</th>
      <th>...</th>
      <th>camp4_Received</th>
      <th>camp5_Received</th>
      <th>complain</th>
      <th>response</th>
      <th>Customer_For</th>
      <th>Age</th>
      <th>Expenditure</th>
      <th>Sons</th>
      <th>FamilySize</th>
      <th>SonPadres</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>...</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2.216000e+03</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
      <td>2216.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>49.012635</td>
      <td>0.441787</td>
      <td>0.505415</td>
      <td>52247.251354</td>
      <td>305.091606</td>
      <td>26.356047</td>
      <td>166.995939</td>
      <td>37.637635</td>
      <td>27.028881</td>
      <td>43.965253</td>
      <td>...</td>
      <td>0.074007</td>
      <td>0.073105</td>
      <td>0.009477</td>
      <td>0.150271</td>
      <td>4.423735e+16</td>
      <td>54.179603</td>
      <td>607.075361</td>
      <td>0.947202</td>
      <td>2.592509</td>
      <td>0.714350</td>
    </tr>
    <tr>
      <th>std</th>
      <td>28.948352</td>
      <td>0.536896</td>
      <td>0.544181</td>
      <td>25173.076661</td>
      <td>337.327920</td>
      <td>39.793917</td>
      <td>224.283273</td>
      <td>54.752082</td>
      <td>41.072046</td>
      <td>51.815414</td>
      <td>...</td>
      <td>0.261842</td>
      <td>0.260367</td>
      <td>0.096907</td>
      <td>0.357417</td>
      <td>2.008532e+16</td>
      <td>11.985554</td>
      <td>602.900476</td>
      <td>0.749062</td>
      <td>0.905722</td>
      <td>0.451825</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1730.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
      <td>27.000000</td>
      <td>5.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>24.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>35303.000000</td>
      <td>24.000000</td>
      <td>2.000000</td>
      <td>16.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>9.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.937600e+16</td>
      <td>46.000000</td>
      <td>69.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>49.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>51381.500000</td>
      <td>174.500000</td>
      <td>8.000000</td>
      <td>68.000000</td>
      <td>12.000000</td>
      <td>8.000000</td>
      <td>24.500000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>4.432320e+16</td>
      <td>53.000000</td>
      <td>396.500000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>74.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>68522.000000</td>
      <td>505.000000</td>
      <td>33.000000</td>
      <td>232.250000</td>
      <td>50.000000</td>
      <td>33.000000</td>
      <td>56.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>5.927040e+16</td>
      <td>64.000000</td>
      <td>1048.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>99.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>666666.000000</td>
      <td>1493.000000</td>
      <td>199.000000</td>
      <td>1725.000000</td>
      <td>259.000000</td>
      <td>262.000000</td>
      <td>321.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>9.184320e+16</td>
      <td>130.000000</td>
      <td>2525.000000</td>
      <td>3.000000</td>
      <td>5.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 28 columns</p>
</div>




```python
## Visualization of some variables

#Design preferences
sns.set(rc={"axes.facecolor":"#FFF9ED","figure.facecolor":"#e6e5e3"})
pallet = ["#2f57f7", "#92c1f7", "#c1d1f7", "#c8cede", "#ab7878", "#f36060"]
cmap = colors.ListedColormap(["#2f57f7", "#92c1f7", "#c1d1f7", "#c8cede", "#ab7878", "#f36060"])

## sns.set(rc={"axes.facecolor":"#FFF9ED","figure.facecolor":"#FFF9ED"})
## Antes pallet = ["#682F2F", "#9E726F", "#D6B2B1", "#B9C0C9", "#9F8A78", "#F3AB60"]
## cmap = colors.ListedColormap(["#682F2F", "#9E726F", "#D6B2B1", "#B9C0C9", "#9F8A78", "#F3AB60"])

#Visualization
To_Plot = [ "income", "daysLastBuy", "Customer_For", "Age", "Expenditure", "SonPadres"]
   
print("Ser padres vs algunas variables: Ingreso, última compra, Edad, Gasto, Padres")
plt.figure()
sns.pairplot(data[To_Plot], hue= "SonPadres",palette= (["#2f57f7","#ff5252"]))
#Taking hue 
plt.show()

## Conclusion:
### There ae some ouliers in Age and Income 
```

    Ser padres vs algunas variables: Ingreso, última compra, Edad, Gasto, Padres
    


    <Figure size 800x550 with 0 Axes>



    
![png](output_10_2.png)
    



```python
# Eliminate outliers in Age & Income

data = data[(data["Age"]<90)]
data = data[(data["income"]<600000)]
print("Total of rows after removing Outliers in Age and Income:", len(data))
```

    Total of rows after removing Outliers in Age and Income: 2212
    


```python
#Correlation Matrix to detect variables correlated 

corrmat= data.corr()
plt.figure(figsize=(20,20))  
sns.heatmap(corrmat,annot=True, cmap=cmap, center=0)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2618352fb50>




    
![png](output_12_1.png)
    



```python
#Detect and find categoricals variables
s = (data.dtypes == 'object')
object_cols = list(s[s].index)

print("Categorical variables in dataset:", object_cols)
```

    Categorical variables in dataset: ['Group_Living', 'Education']
    


```python
# Formatting all vriables to Numeric

LE=LabelEncoder()
for i in object_cols:
    data[i]=data[[i]].apply(LE.fit_transform)
    
print("All variabels are now Numeric")
```

    All variabels are now Numeric
    


```python
# Create a copy of datset

ds = data.copy()
# Create a subset of data by removing the variables with offers and promotions received

cols_del = ['camp1_Received', 'camp2_Received', 'camp3_Received', 'camp4_Received', 'camp5_Received', 'complain', 'response']
ds = ds.drop(cols_del, axis=1)

#Scaling the data

scaler = StandardScaler()
scaler.fit(ds)
scaled_ds = pd.DataFrame(scaler.transform(ds),columns= ds.columns )
print("All variables have been scaled")

## Scale the data to have a mean equal to 0 and a standard deviation equal to one
## Useful for working with Clusters models that assume variables have a normal distribution
```

    All variables have been scaled
    


```python
# Scaled data used to reduce dimensionality

print("Dataset to be use un Modelling:")
scaled_ds.head()
```

    Dataset to be use un Modelling:
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>daysLastBuy</th>
      <th>kids</th>
      <th>teenagers</th>
      <th>income</th>
      <th>wines</th>
      <th>fruits</th>
      <th>meat</th>
      <th>fish</th>
      <th>candy</th>
      <th>gold</th>
      <th>...</th>
      <th>storePurchases</th>
      <th>webVisits_Month</th>
      <th>Customer_For</th>
      <th>Age</th>
      <th>Expenditure</th>
      <th>Group_Living</th>
      <th>Sons</th>
      <th>FamilySize</th>
      <th>SonPadres</th>
      <th>Education</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.310353</td>
      <td>-0.822754</td>
      <td>-0.929699</td>
      <td>0.287105</td>
      <td>0.977660</td>
      <td>1.552041</td>
      <td>1.690293</td>
      <td>2.453472</td>
      <td>1.483713</td>
      <td>0.852576</td>
      <td>...</td>
      <td>-0.555814</td>
      <td>0.692181</td>
      <td>1.973583</td>
      <td>1.018352</td>
      <td>1.676245</td>
      <td>-1.349603</td>
      <td>-1.264598</td>
      <td>-1.758359</td>
      <td>-1.581139</td>
      <td>-0.893586</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.380813</td>
      <td>1.040021</td>
      <td>0.908097</td>
      <td>-0.260882</td>
      <td>-0.872618</td>
      <td>-0.637461</td>
      <td>-0.718230</td>
      <td>-0.651004</td>
      <td>-0.634019</td>
      <td>-0.733642</td>
      <td>...</td>
      <td>-1.171160</td>
      <td>-0.132545</td>
      <td>-1.665144</td>
      <td>1.274785</td>
      <td>-0.963297</td>
      <td>-1.349603</td>
      <td>1.404572</td>
      <td>0.449070</td>
      <td>0.632456</td>
      <td>-0.893586</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.795514</td>
      <td>-0.822754</td>
      <td>-0.929699</td>
      <td>0.913196</td>
      <td>0.357935</td>
      <td>0.570540</td>
      <td>-0.178542</td>
      <td>1.339513</td>
      <td>-0.147184</td>
      <td>-0.037254</td>
      <td>...</td>
      <td>1.290224</td>
      <td>-0.544908</td>
      <td>-0.172664</td>
      <td>0.334530</td>
      <td>0.280110</td>
      <td>0.740959</td>
      <td>-1.264598</td>
      <td>-0.654644</td>
      <td>-1.581139</td>
      <td>-0.893586</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-0.795514</td>
      <td>1.040021</td>
      <td>-0.929699</td>
      <td>-1.176114</td>
      <td>-0.872618</td>
      <td>-0.561961</td>
      <td>-0.655787</td>
      <td>-0.504911</td>
      <td>-0.585335</td>
      <td>-0.752987</td>
      <td>...</td>
      <td>-0.555814</td>
      <td>0.279818</td>
      <td>-1.923210</td>
      <td>-1.289547</td>
      <td>-0.920135</td>
      <td>0.740959</td>
      <td>0.069987</td>
      <td>0.449070</td>
      <td>0.632456</td>
      <td>-0.893586</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.554453</td>
      <td>1.040021</td>
      <td>-0.929699</td>
      <td>0.294307</td>
      <td>-0.392257</td>
      <td>0.419540</td>
      <td>-0.218684</td>
      <td>0.152508</td>
      <td>-0.001133</td>
      <td>-0.559545</td>
      <td>...</td>
      <td>0.059532</td>
      <td>-0.132545</td>
      <td>-0.822130</td>
      <td>-1.033114</td>
      <td>-0.307562</td>
      <td>0.740959</td>
      <td>0.069987</td>
      <td>0.449070</td>
      <td>0.632456</td>
      <td>0.571657</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 23 columns</p>
</div>




```python
# Start Component Analysis (PCA) to reduce variables



pca = PCA(n_components=8)
pca.fit(scaled_ds)
PCA_ds = pd.DataFrame(pca.transform(scaled_ds), columns=(["variable1","variable2", "variable3", "variable4",
                                                         "variable5", "variable6","variable7", "variable8"]))


## PCA_ds = pd.DataFrame(pca.transform(scaled_ds), columns=(["variable1","variable2", "variable3", "variable4",
                                                        #   "variable5", "variable6","variable7", "variable8", 
                                                        # "variable9", "variable10"]))
PCA_ds.describe().T



## pca.explained_variance_ratio_
pca.explained_variance_ratio_.sum()

## Conlusion 
### The reduction to 8 variables contribute in 77% of the explanation








```




    0.7787884057558626




```python
# Quick examination of elbow method to find numbers of clusters to make

print('The Elbow Method to determine the number of Clusters that we should form:')
Elbow_M = KElbowVisualizer(KMeans(), k=(8))
Elbow_M.fit(PCA_ds)
Elbow_M.show()
```

    The Elbow Method to determine the number of Clusters that we should form:
    


    
![png](output_18_1.png)
    





    <matplotlib.axes._subplots.AxesSubplot at 0x261823a0160>




```python
# Starting the grouping or Clustering Model


AC = AgglomerativeClustering(n_clusters=4)

# Fit the Model and Predict the Clusters
yhat_AC = AC.fit_predict(PCA_ds)
PCA_ds["Clusters"] = yhat_AC
# Adding the Clusters to the original dataframe

data["Clusters"]= yhat_AC
```


```python
#Displaying the Clusters or Groups

#A 3D Projection Of Data In The Reduced Dimension
x =PCA_ds["variable1"]
y =PCA_ds["variable2"]
z =PCA_ds["variable3"]



fig = plt.figure(figsize=(10,8))
ax = plt.subplot(111, projection='3d', label="bla")
ax.scatter(x, y, z, s=40, c=PCA_ds["Clusters"], marker='o', cmap = cmap )
ax.set_title("Segmentation | Clusters")
plt.show()
```


    
![png](output_20_0.png)
    



```python
#Display the Count by Groups

pal = ["#2f57f7","#edd768", "#5ff55f","#f74d4d"]

pl = sns.countplot(x=data["Clusters"], palette= pal)
pl.set_title("Clusters Distribution")
plt.show()
```


    
![png](output_21_0.png)
    



```python
### Income vs Expenditure per Clusters

pl = sns.scatterplot(data=data, x=data["income"], y=data["Expenditure"], hue=data["Clusters"], palette = pal)

pl.set_title("Income vs Expenditure per Clusters")
plt.legend()
plt.show()



```


    
![png](output_22_0.png)
    



```python
## Distribution of consumption in the supermarket by Groups/Clusters

plt.figure()
pl = sns.swarmplot(x=data["Clusters"], y=data["Expenditure"], color = "#e6f7f0", alpha = 0.5)
pl = sns.boxenplot(x=data["Clusters"], y=data["Expenditure"], palette = pal)
plt.show()


```


    
![png](output_23_0.png)
    



```python
## Display the distribution of the number of Deals

plt.figure()
pl=sns.boxenplot(y=data["dealsPurchases"], x=data["Clusters"], palette = pal)
pl.set_title("Number of Promotions Acquiered")
plt.show()

```


    
![png](output_24_0.png)
    



```python
### Profiling Cluster groups


data["Campaigns"] = data["camp1_Received"] + data["camp2_Received"] + data["camp3_Received"] + data["camp4_Received"] + data["camp5_Received"]


Personal = ["SonPadres", "Sons", "kids","teenagers", "FamilySize", "Group_Living", "Campaigns", "dealsPurchases", "Age", "webPurchases", "catalogPurchases"]

for i in Personal:
    plt.figure()
    sns.jointplot(x=data[i], y=data["Expenditure"], hue=data["Clusters"], kind="kde", palette=pal)
    plt.show()

```


    <Figure size 800x550 with 0 Axes>



    
![png](output_25_1.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_3.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_5.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_7.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_9.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_11.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_13.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_15.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_17.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_19.png)
    



    <Figure size 800x550 with 0 Axes>



    
![png](output_25_21.png)
    



```python
### Final Conclusions


- Red Group (Cluster 3):
     - They are over 40 years old with high income
     - They are Parents, most of them teenagers
     - They are a family group of 3 members
     - They react very well to promotions, and to a lesser extent to campaigns
    
- Green Group (Cluster 2):
     - They are a group of diverse ages, from 30 years old
     - They are the group with the highest income and the highest consumption in the supermarket
     - They are not parents
     - It is a group of Couples or Singles
     - They have a high sensitivity to campaigns, but very low to promotions
        
 - Yellow Group (Cluster 1):
     - They have average income and low consumption in supermarkets
     - They are Parents, with at least one child and one adolescent at home
     - They have high sensitivity to promotions, and moderate to campaigns
     - They are adults from the age of 40
     - It is a family group mainly 4 members
    
- Blue Group (Cluster 0):
     - They are the youngest group, from the age of 20
     - They have low income, and the least consumption in the supermarket
     - They have a moderate to low acceptance of campaigns and promotions
     - A considerable percentage are parents of at least 1 child 


```
